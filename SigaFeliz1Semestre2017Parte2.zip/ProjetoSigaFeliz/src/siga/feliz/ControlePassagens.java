
package siga.feliz;

import java.util.Scanner;

/**
 * @author GRUPO PROJETO INTEGRADO I AKV
 * Entrega - Parte 2 
 * Projeto Integrado | - Ano 2017
 * Análise e desenvolvimento de sistemas
 * Alunos:
 * VINICIUS ROBERTO DE OLIVEIRA SANTOS  RA: 21011581
 * MATHEUS DA SILVA FERREIRA            RA: 21025005
 * HENRIQUE EUGENIO PIOVESAN ROSENSTOCK RA: 20153323
 */
public class ControlePassagens {
    
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        
        int[] janela = new int[24];
        int[] corredor = new int[24];
        int opcao, poltrona;
        char jc = 'J';
        opcao =0;
        
        do{
            
        scan.reset();
        System.out.println("\n|--------BEM VINDO OPERADOR---------|");
        System.out.println("|     MENU - VENDA DE PASSAGENS     |");
        System.out.println("|-----------------------------------|");
        System.out.println("|      1 - Vender a Passagem        |");
        System.out.println("|      2 - Mapa de Ocupações        |");
        System.out.println("|      3 - Sair                     |");
        System.out.println("|-----------------------------------|");

        try {
            opcao = scan.nextInt();

            if (opcao == 1 || opcao ==2 || opcao ==3){
                switch (opcao){
                    case 1:

                        /**
                        * @author GRUPO PROJETO INTEGRADO I AKV
                        * Verifica se todos os lugares estão ocupados
                        **/
                        int contadorJanela, cont = 0;
                        for(contadorJanela = 0; contadorJanela < janela.length; contadorJanela++){
                            if(janela[contadorJanela] == 1 && corredor[contadorJanela] == 1){
                               cont++;
                            }
                        }

                        /**
                        * @author GRUPO PROJETO INTEGRADO I AKV
                        * Caso o cont esteja com o valor 24 é pelo fato de que todas as poltronas estão ocupadas
                        **/
                        if (cont == 24){
                             System.out.println("\n|---------------------------|");
                             System.out.println("|      Ônibus, LOTADO !       |");
                             System.out.println("|-----------------------------|\n");
                             break;
                        }

                        /**
                        * @author GRUPO PROJETO INTEGRADO I AKV
                        * Solicita o número da Poltrona e valida o número da Poltrona
                        **/
                        poltrona=0;
                        do {
                            try {
                                System.out.print("Digite o Número da Poltrona (1 a 24): ");
                                poltrona = scan.nextInt();
                                if (poltrona < 1 || poltrona > 24){
                                    System.out.print("\n Ocorreu um ERRO, verifique se o número da poltrona foi digitado corretamente!\n");
                                }
                            }catch (Exception e) {
                                System.out.print("\n Ocorreu um ERRO, verifique se o número da poltrona foi digitado corretamente!\n");
                                //Limpa o buffer do teclado
                                scan.nextLine();
                            }
                        
                        } while (poltrona < 1 || poltrona > 24);

                        /**
                        * @author GRUPO PROJETO INTEGRADO I AKV
                        * Solicita se Janela ou Corredor e valida o assento
                        **/    

                        int lado = 5;
                        do {
                            System.out.print("Digite (J) Janela ou (C) Corredor: ");
                            jc = scan.next().charAt(0);
                                if(jc == 'J' || jc == 'j'){
                                    lado = 0;
                                }else if (jc == 'C' || jc == 'c'){
                                    lado = 1;
                                } else {
                                    System.out.println("\n Ocorreu um ERRO, localização da poltrona inválida! \n");
                                }
                        }   while (lado != 0 && lado != 1);

                        /**
                        * @author GRUPO PROJETO INTEGRADO I AKV
                        * Verifica se a Poltrona está disponível, faz atribuição e muda o status da Poltrona
                        **/             
                        if(jc == 'J' || jc == 'j'){
                            if (janela[poltrona -1] == 0){
                                janela[poltrona - 1] = 1;
                            } else {
                                System.out.println("\n Alerta, A Poltrona escolhida está OCUPADA \nTente outro Assento ou consulte o 'Mapa de Ocupação'\n");
                                break;
                            }
                        } else {
                            if(corredor[poltrona -1] == 0){
                            corredor[poltrona - 1] = 1;
                            } else {
                                System.out.println("\n <!!! ERRO !!!>  Poltrona OCUPADA \nTente outro Assento ou consulte o 'Mapa de Ocupação'\n");
                                break;
                            }
                        }
                        // Exibe qual o lugar foi vendido
                        System.out.println("\n|---------------------------------------------------|");
                        System.out.println("| Parabéns, a Compra foi efetuada com sucesso:      | \n Lado da Poltrono: " + ((lado == 0)? "Janela, " : "Corredor, ") + "\n Número da Poltrona: " + poltrona);
                        System.out.println("|---------------------------------------------------|\n");
                        break;
                    case 2:
                        System.out.println("\n|----------------------------------|");
                        System.out.println("| M A P A   D E   O C U P A Ç Ã O:  |");
                        System.out.println("| --------------------------------  |");

                        System.out.println(" JANELA           CORREDOR");
                        int contador = 0;
                        for (contador = 0; contador < janela.length; contador++){ // corre o vetor
                            System.out.print((contador+1) + " - ");
                            if (janela[contador] != 0){
                                System.out.print("Ocupado      " + (contador+1) + " - ");
                            } else {
                                System.out.print("Livre        " + (contador+1) + " - ");
                            } 
                            if (corredor[contador] != 0){ // corre o vetor
                                System.out.println("Ocupado");
                            } else {
                                System.out.println("Livre");
                            }
                        }      
                        break;
                    default:
                        System.out.println("\n Encerrando o Programa - Siga Feliz");
                        System.exit(0);
                }
            }else{
                System.out.println("\n Ocorreu um ERRO! \n Entre com a Opção ( 1, 2, 3 ) correspondente\n");
            }
        }
        catch (Exception e) {
           System.out.println("Ocorreu um ERRO, digite somente números");
           //Limpa o buffer do teclado
           scan.nextLine();
        }   
        } while (opcao != 1 || opcao != 2);
    }
}
